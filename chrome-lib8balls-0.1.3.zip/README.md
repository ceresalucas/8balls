chrome-libdoge
==============

such chrome extension for libdoge wow

Chrome Extension available at Chrome Store
https://chrome.google.com/webstore/detail/such-good-doge/ifbchccfedjkkhlnffjckaghjdpchhmo

doge itself lives at https://github.com/ljalonen/libdoge

[![Bitdeli Badge](https://d2weczhvl823v0.cloudfront.net/ljalonen/chrome-libdoge/trend.png)](https://bitdeli.com/free "Bitdeli Badge")